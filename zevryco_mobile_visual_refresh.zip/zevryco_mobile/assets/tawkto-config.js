/* ZEVRYCO MOBILE — live chat configuration
   Create a free account at https://www.tawk.to/ and add your site as a Property.
   In Administration > Chat Widget, copy the unique embed URL from the script's s1.src value.
   Paste only that URL between the quotes below. Do not put your account password here.
*/
window.ZEVRYCO_TAWK_WIDGET_URL = "";
