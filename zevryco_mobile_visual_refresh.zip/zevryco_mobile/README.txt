ZEVRYCO MOBILE — WEBSITE PACKAGE

This package contains the storefront and a secure server-side Stripe Checkout scaffold designed for Netlify Functions.

Included:
- Premium responsive product catalog for Apple iPhone/iPad, Samsung and Motorola.
- Shopping bag and customer contact form.
- tawk.to live-chat integration point (requires your own widget URL).
- Netlify configuration and serverless Stripe Checkout/webhook endpoints.
- Server-side SKU catalog template; prices are never trusted from the browser.
- Checkout is deliberately disabled until real SKU stock, pricing, taxes, shipping and order handling are configured.

Start with NEXT-STEPS-PT.txt. Do not enable live payments just because the payment provider account exists. The current catalog.json is empty and the webhook does not yet provide a complete order-management dashboard or atomic inventory control.
