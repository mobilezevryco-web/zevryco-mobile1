import Stripe from "stripe";
import catalog from "./catalog.json" with { type: "json" };

const reply = (statusCode, payload) => ({
  statusCode,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify(payload),
});

export const handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { message: "Method not allowed." });

  // Keep live checkout disabled until each sellable SKU, real stock quantity,
  // tax/shipping rules, and order handling have been verified by the store owner.
  if (process.env.CHECKOUT_ENABLED !== "true") {
    return reply(503, {
      code: "CHECKOUT_NOT_READY",
      message: "Online payments are not active yet. The store owner must finish the real-stock, pricing, tax, shipping and payment setup. No payment was taken."
    });
  }

  const secretKey = process.env.STRIPE_SECRET_KEY;
  const siteUrl = process.env.SITE_URL;
  const shippingRateId = process.env.STRIPE_SHIPPING_RATE_ID;
  if (!secretKey || !siteUrl || !shippingRateId) {
    return reply(503, { message: "The secure payment service and U.S. shipping rate are not fully configured." });
  }

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return reply(400, { message: "Invalid request." }); }

  const email = String(body?.customer?.email || "").trim();
  const customerName = String(body?.customer?.name || "").trim().slice(0, 120);
  const items = body?.items;
  if (!/^\S+@\S+\.\S+$/.test(email) || !Array.isArray(items) || items.length < 1 || items.length > 12) {
    return reply(400, { message: "Please provide a valid email address and a valid shopping cart." });
  }

  const line_items = [];
  for (const item of items) {
    const id = String(item?.id || "");
    const color = String(item?.color || "");
    const storage = String(item?.storage || "");
    const network = String(item?.network || "");
    const quantity = Number(item?.quantity);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 5) {
      return reply(400, { message: "Each item quantity must be between 1 and 5." });
    }

    // This server-side catalog, not browser-provided prices, is the source of truth.
    const product = catalog.products?.[id];
    const variant = product?.variants?.find((v) =>
      v.color === color && v.storage === storage && (!v.network || v.network === network)
    );
    if (!product || product.active !== true || !variant || !Number.isInteger(variant.priceCents) || variant.priceCents < 50 || !Number.isInteger(variant.quantityAvailable) || variant.quantityAvailable < quantity) {
      return reply(409, {
        code: "SKU_NOT_CONFIGURED",
        message: "One or more selected models are not yet configured with a verified price and available stock. Please contact customer support. No payment was taken."
      });
    }

    line_items.push({
      quantity,
      price_data: {
        currency: "usd",
        unit_amount: variant.priceCents,
        product_data: {
          name: `${product.name} — ${storage} — ${color}`,
          description: [network, "Brand new"].filter(Boolean).join(" · ")
        }
      }
    });
  }

  try {
    const stripe = new Stripe(secretKey);
    const baseUrl = siteUrl.replace(/\/$/, "");
    const automaticTax = process.env.STRIPE_AUTOMATIC_TAX === "true";
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      line_items,
      customer_email: email,
      billing_address_collection: "required",
      shipping_address_collection: { allowed_countries: ["US"] },
      shipping_options: [{ shipping_rate: shippingRateId }],
      phone_number_collection: { enabled: true },
      ...(automaticTax ? { automatic_tax: { enabled: true } } : {}),
      success_url: `${baseUrl}/order-success.html?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${baseUrl}/?checkout=cancelled#shop`,
      metadata: {
        store: "ZEVRYCO MOBILE",
        customer_name: customerName
      }
    });
    return reply(200, { url: session.url });
  } catch (error) {
    console.error("Stripe Checkout creation failed:", error?.message || error);
    return reply(500, { message: "Unable to start secure checkout. Please contact customer support." });
  }
};
