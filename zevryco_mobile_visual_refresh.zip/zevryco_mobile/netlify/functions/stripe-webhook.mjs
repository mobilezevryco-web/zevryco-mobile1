import Stripe from "stripe";

export const handler = async (event) => {
  if (event.httpMethod !== "POST") return { statusCode: 405, body: "Method not allowed" };

  const secretKey = process.env.STRIPE_SECRET_KEY;
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;
  if (!secretKey || !webhookSecret) return { statusCode: 503, body: "Webhook is not configured" };

  const signature = event.headers["stripe-signature"] || event.headers["Stripe-Signature"];
  if (!signature || !event.body) return { statusCode: 400, body: "Missing webhook signature or body" };

  const rawBody = event.isBase64Encoded
    ? Buffer.from(event.body, "base64")
    : event.body;

  try {
    const stripe = new Stripe(secretKey);
    const stripeEvent = stripe.webhooks.constructEvent(rawBody, signature, webhookSecret);

    // These events are written to Netlify function logs. Before enabling live sales,
    // connect this verified webhook to a persistent order-management/notification system.
    switch (stripeEvent.type) {
      case "checkout.session.completed":
      case "checkout.session.async_payment_succeeded": {
        const session = stripeEvent.data.object;
        console.log("ZEVRYCO PAID ORDER", JSON.stringify({
          sessionId: session.id,
          paymentStatus: session.payment_status,
          amountTotal: session.amount_total,
          currency: session.currency,
          customerEmail: session.customer_details?.email || session.customer_email,
          created: session.created
        }));
        break;
      }
      case "checkout.session.async_payment_failed":
      case "checkout.session.expired":
        console.log("ZEVRYCO CHECKOUT UPDATE", stripeEvent.type, stripeEvent.data.object.id);
        break;
      default:
        console.log("Stripe event received:", stripeEvent.type);
    }

    return { statusCode: 200, body: JSON.stringify({ received: true }) };
  } catch (error) {
    console.error("Stripe webhook signature verification failed:", error?.message || error);
    return { statusCode: 400, body: "Invalid webhook signature" };
  }
};
